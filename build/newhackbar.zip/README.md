# New Hackbar
This A sitebar that helps you pentest website which is writed in webextension which alternatives to XUL Hackbar version.